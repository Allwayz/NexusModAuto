#!/usr/bin/env bash

cd "`dirname "$0"`"
internal/linux/SMAPI.Installer
